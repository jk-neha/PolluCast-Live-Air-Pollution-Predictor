##openweather api - data collection

import requests
import datetime
API_KEY = "09f32567882a99651d51fd9064202419"
CITY = "Chennai"
URL = f"https://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
print("THE OPENWEATHER API HAD BEEN FOUND")

# MAKING TEH REQUEST TO THE OPENWEATHER API
response = requests.get(URL)
print("GOT THE RESPONSE")

# CHECKING FOR THE SUCCESS OF THE CODE
if response.status_code == 200:
    data = response.json()
    print("OPENWEAATHERMAP API RESPONSE :")
    print("-" * 40)
    print("City:", data['name'])
    print("Temperature (°C):", data['main']['temp'])
    print("Humidity (%):", data['main']['humidity'])
    print("Pressure (hPa):", data['main']['pressure'])
    print("Wind Speed (m/s):", data['wind']['speed'])
    print("Weather Condition:", data['weather'][0]['main'])
    print("Timestamp:", datetime.datetime.now())
else:
    print("Failed to fetch data:", response.status_code)
