#to tun
# python Alert_System.py
#  =========================================
# PolluCast: Combined Alerts Script with Logging
# =========================================

# =========================================
# PolluCast: Combined Alerts Script with Logging
# =========================================

import pandas as pd
from datetime import datetime
from twilio.rest import Client
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

# ========================
# Twilio config
# ========================
TWILIO_ACCOUNT_SID = 'AC9ef71738abaf53908d9e599148b430bd'
TWILIO_AUTH_TOKEN = '1ec0a96f8df00ca23c6083b607e68923'
TWILIO_SMS_NUMBER = '+17163404256'
TWILIO_WHATSAPP_NUMBER = 'whatsapp:+14155238886'

MY_PHONE_SMS = '+918122978440'
MY_PHONE_WHATSAPP = 'whatsapp:+918122978440'

twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# ========================
# Email config
# ========================
SENDER_EMAIL = 'airpollutionpredictor024@gmail.com'
APP_PASSWORD = 'mhkk qidt flrn ybpv'
RECEIVER_EMAIL = 'femeeaberigith@gmail.com'

# ========================
# Paths
# ========================
CSV_PATH = 'mpaqi_data_collections.csv'
LOG_PATH = 'aqi_alert_log.csv'

# ========================
# Read latest AQI
# ========================
df = pd.read_csv(CSV_PATH)
latest_aqi = df['AQI'].iloc[-1]

# Determine AQI category
def get_aqi_category(aqi):
    if aqi <= 50:
        return "Good (Safe)"
    elif aqi <= 100:
        return "Moderate (Safe)"
    elif aqi <= 150:
        return "Unhealthy for Sensitive Groups (Unsafe)"
    elif aqi <= 200:
        return "Unhealthy (Unsafe)"
    elif aqi <= 300:
        return "Very Unhealthy (Unsafe)"
    else:
        return "Hazardous (Unsafe)"

aqi_category = get_aqi_category(latest_aqi)

# Prepare alert message
alert_message = f"⚠️ PolluCast Alert!\nPredicted AQI: {latest_aqi}\nCategory: {aqi_category}\nStay safe 🌿"
print("Alert message preview:")
print(alert_message)

# Initialize alert status
alert_status = "Not Sent"

# ========================
# Send SMS
# ========================
try:
    sms = twilio_client.messages.create(
        body=alert_message,
        from_=TWILIO_SMS_NUMBER,
        to=MY_PHONE_SMS
    )
    print("✅ SMS sent! SID:", sms.sid)
    alert_status = "Sent"
except Exception as e:
    print("❌ Failed to send SMS:", e)
    alert_status = f"SMS Failed: {e}"

# ========================
# Send WhatsApp
# ========================
try:
    whatsapp = twilio_client.messages.create(
        body=alert_message,
        from_=TWILIO_WHATSAPP_NUMBER,
        to=MY_PHONE_WHATSAPP
    )
    print("✅ WhatsApp sent! SID:", whatsapp.sid)
except Exception as e:
    print("❌ Failed to send WhatsApp:", e)
    alert_status += f" | WhatsApp Failed: {e}"

# ========================
# Send Email
# ========================
try:
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = RECEIVER_EMAIL
    msg['Subject'] = f"⚠️ PolluCast AQI Alert: {aqi_category}"
    msg.attach(MIMEText(alert_message, 'plain'))

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(SENDER_EMAIL, APP_PASSWORD)
    server.send_message(msg)
    server.quit()

    print("✅ Email sent!")
except Exception as e:
    print("❌ Failed to send Email:", e)
    alert_status += f" | Email Failed: {e}"

# ========================
# Log the alert
# ========================
log_data = pd.DataFrame([{
    'Timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    'AQI': latest_aqi,
    'AQI_Category': aqi_category,
    'Alert_Status': alert_status
}])

# Create log file if not exists
if os.path.exists(LOG_PATH):
    log_data.to_csv(LOG_PATH, mode='a', header=False, index=False)
else:
    log_data.to_csv(LOG_PATH, mode='w', header=True, index=False)

print("✅ Alert logged in", LOG_PATH)
