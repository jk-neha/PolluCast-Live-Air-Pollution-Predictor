# to run -->
# python compare_all_models.py

import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb

# ================= Step 1: Load Dataset =================
data = pd.read_csv("mpaqi_data_collections.csv")

features = ['pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']
X = data[features]
y = data['AQI']

# Standardize for SVR
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# ================= Step 2: Train Models =================

# --- Random Forest ---
rf = RandomForestRegressor(n_estimators=200, random_state=42)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)

# --- XGBoost ---
xgb_model = xgb.XGBRegressor(
    n_estimators=300,
    learning_rate=0.1,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)
xgb_model.fit(X_train, y_train)
xgb_pred = xgb_model.predict(X_test)

# --- SVR ---
svr_model = SVR(kernel='rbf', C=100, gamma=0.1, epsilon=0.1)
svr_model.fit(X_train, y_train)
svr_pred = svr_model.predict(X_test)

# ================= Step 3: Evaluation =================
def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2

rf_metrics = evaluate(y_test, rf_pred)
xgb_metrics = evaluate(y_test, xgb_pred)
svr_metrics = evaluate(y_test, svr_pred)

print("\n📊 Model Performance:")
print(f"Random Forest -> MAE={rf_metrics[0]:.2f}, RMSE={rf_metrics[1]:.2f}, R²={rf_metrics[2]:.4f}")
print(f"XGBoost       -> MAE={xgb_metrics[0]:.2f}, RMSE={xgb_metrics[1]:.2f}, R²={xgb_metrics[2]:.4f}")
print(f"SVR           -> MAE={svr_metrics[0]:.2f}, RMSE={svr_metrics[1]:.2f}, R²={svr_metrics[2]:.4f}")

# ================= Step 4: Visualization =================
metrics = ["MAE", "RMSE", "R²"]
x = np.arange(len(metrics))
width = 0.25

plt.figure(figsize=(9,6))
bars1 = plt.bar(x - width, rf_metrics, width, label="Random Forest", color="purple")
bars2 = plt.bar(x, xgb_metrics, width, label="XGBoost", color="black")
bars3 = plt.bar(x + width, svr_metrics, width, label="SVR", color="blue")

# Add values
for bars in [bars1, bars2, bars3]:
    for bar in bars:
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f"{bar.get_height():.2f}", ha="center", va="bottom", fontsize=9)

plt.xticks(x, metrics)
plt.ylabel("Score")
plt.title("Evaluation Metrics Comparison (RF vs XGBoost vs SVR)", fontsize=14, weight="bold")
plt.legend()
plt.tight_layout()
plt.show()

# ================= Step 5: Accuracy Calculation =================
mean_y = np.mean(y_test)

rf_acc = (1 - rf_metrics[0] / mean_y) * 100
xgb_acc = (1 - xgb_metrics[0] / mean_y) * 100
svr_acc = (1 - svr_metrics[0] / mean_y) * 100

accuracies = [rf_acc, xgb_acc, svr_acc]
models = ["Random Forest", "XGBoost", "SVR"]

print("\n✅ Accuracy Comparison:")
print(f"Random Forest Accuracy: {rf_acc:.2f}%")
print(f"XGBoost Accuracy      : {xgb_acc:.2f}%")
print(f"SVR Accuracy          : {svr_acc:.2f}%")

# ================= Step 6: Accuracy Visualization =================

plt.figure(figsize=(7,5))
bars = plt.bar(models, accuracies, color=["purple", "black", "blue"], width=0.5)

# Add value labels
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 0.1,
             f"{yval:.2f}%", ha="center", va="bottom", fontsize=10)

plt.ylabel("Accuracy (%)")
plt.title("Model Accuracy Comparison", fontsize=14, weight="bold")

# Zoom y-axis to focus between 90–100%
plt.ylim(90, 100)

plt.tight_layout()
plt.show()
