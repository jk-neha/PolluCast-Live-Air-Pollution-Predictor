
# sms_alert.py

from twilio.rest import Client

# ====== Twilio Configuration ======
ACCOUNT_SID = 'AC9ef71738abaf53908d9e599148b430bd'
AUTH_TOKEN = '1ec0a96f8df00ca23c6083b607e68923'            # Your Twilio Auth Token
TWILIO_PHONE = '+17163404256'                    # Your Twilio number (SMS capable)
MY_PHONE_SMS = '+918122978440'                  # Your verified personal number

# Initialize Twilio client
client = Client(ACCOUNT_SID, AUTH_TOKEN)

# ====== SMS Alert Function ======
def send_sms_alert(aqi_value):
    try:
        message = client.messages.create(
            body=f"⚠️ Air Quality Alert! AQI is {aqi_value}. Take precautions!",
            from_=TWILIO_PHONE,
            to=MY_PHONE_SMS
        )
        print(f"✅ SMS sent: {message.sid}")
    except Exception as e:
        print(f"❌ Failed to send SMS: {e}")

# ====== Example AQI Prediction ======
model_predictions = [180, 210, 195]  # Replace with your actual model outputs

# Send SMS if AQI > 200
for aqi in model_predictions:
    if aqi > 200:
        send_sms_alert(aqi)
