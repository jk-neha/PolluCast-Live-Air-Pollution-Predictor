# to run -->
# python predict_realtime_aqi.py

import requests
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler

# ================= Step 1: Config =================
API_KEY = "09f32567882a99651d51fd9064202419"   # replace with your key
LOCATION = "Nungambakkam,Chennai,IN"

# Models
rf_model = joblib.load("aqi_rf_model.pkl")
xgb_model = joblib.load("aqi_xgb_model.pkl")
svr_model = joblib.load("aqi_svr_model.pkl")
scaler = joblib.load("svr_scaler.pkl")

# Features needed
features = ['pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']


# ================= Step 2: Fetch Live Data =================
def get_live_data(location, api_key):
    # Geocode
    geo_url = "http://api.openweathermap.org/geo/1.0/direct"
    geo_params = {"q": location, "limit": 1, "appid": api_key}
    geo_resp = requests.get(geo_url, params=geo_params).json()
    lat, lon = geo_resp[0]["lat"], geo_resp[0]["lon"]

    # Air pollution data
    url = "http://api.openweathermap.org/data/2.5/air_pollution"
    params = {"lat": lat, "lon": lon, "appid": api_key}
    resp = requests.get(url, params=params).json()

    comps = resp["list"][0]["components"]
    row = {f: comps.get(f) for f in features}
    return pd.DataFrame([row])


# ================= Step 3: Predict with Models =================
def predict_aqi(live_df):
    # Scale for SVR
    scaled = scaler.transform(live_df)

    rf_pred = rf_model.predict(live_df)[0]
    xgb_pred = xgb_model.predict(live_df)[0]
    svr_pred = svr_model.predict(scaled)[0]

    return rf_pred, xgb_pred, svr_pred


# ================= Step 4: Main =================
if __name__ == "__main__":
    live_data = get_live_data(LOCATION, API_KEY)
    print("\n🌍 Live Pollutant Data:\n", live_data)

    rf_pred, xgb_pred, svr_pred = predict_aqi(live_data)

    print("\n📊 Predicted AQI Values:")
    print(f"Random Forest -> {rf_pred:.2f}")
    print(f"XGBoost       -> {xgb_pred:.2f}")
    print(f"SVR           -> {svr_pred:.2f}")

    # Decide final AQI (using RF as best model)
    final_aqi = rf_pred
    print(f"\n✅ Final AQI (Using Random Forest): {final_aqi:.2f}")

    # Alerts
    if final_aqi > 200:
        print("🚨 ALERT: Air Quality is Unhealthy! Take precautions.")
    else:
        print("✅ Air Quality is Safe.")
