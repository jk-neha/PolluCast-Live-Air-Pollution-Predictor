#to run--->
#  python "feature_imoprtance_comparison.py"

# feature_importance_comparison.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import numpy as np

# Load dataset
df = pd.read_csv("mpaqi_data_collections.csv")

features = ['pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']
target = 'aqi'

X = df[features]
y = df[target]

# Load trained models
rf = joblib.load("aqi_rf_model.pkl")
xgb_model = joblib.load("aqi_xgb_model.pkl")

# Get feature importances
rf_importances = rf.feature_importances_
xgb_importances = xgb_model.feature_importances_

# Create DataFrame
importance_df = pd.DataFrame({
    "Feature": features,
    "Random Forest": rf_importances,
    "XGBoost": xgb_importances
}).set_index("Feature")

# Normalize for better comparison
importance_df = importance_df.div(importance_df.max(axis=0))

# Sort by mean importance
importance_df["Mean"] = importance_df.mean(axis=1)
importance_df = importance_df.sort_values("Mean", ascending=False).drop(columns="Mean")

# Plot
sns.set(style="whitegrid", font_scale=1.2)
ax = importance_df.plot(
    kind="bar", 
    figsize=(12,6), 
    width=0.75, 
    color=["#111a11", "#af03e8"],  # Blue & Orange
    edgecolor="black"
)

plt.title("🌍 Feature Importance Comparison: Random Forest vs XGBoost", fontsize=16, weight="bold")
plt.ylabel("Relative Importance (0-1)")
plt.xlabel("Feature")
plt.xticks(rotation=45)

# Add value labels on bars
for container in ax.containers:
    ax.bar_label(container, fmt="%.2f", label_type="edge", fontsize=9)

plt.legend(title="Model", fontsize=12)
plt.tight_layout()
plt.show()


import matplotlib.pyplot as plt

# Example data (replace with your actual values)
epochs = [1, 2, 3, 4, 5]
rf_accuracy = [0.72, 0.75, 0.78, 0.80, 0.82]
xg_accuracy = [0.70, 0.74, 0.77, 0.81, 0.83]

# Plotting
plt.figure(figsize=(8,5))
plt.plot(epochs, rf_accuracy, marker='o', color='purple', linestyle='-', label="Random Forest")
plt.plot(epochs, xg_accuracy, marker='s', color='black', linestyle='--', label="XGBoost")

# Labels & Title
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("Model Accuracy Comparison")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)

# Show plot
plt.show()
