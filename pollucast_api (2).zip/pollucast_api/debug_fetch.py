import requests

# ---------------- CONFIG ----------------
THINGER_BUCKET = "pollucast_data"
THINGER_URL = f"https://api.thinger.io/v3/users/jknehavardhini/buckets/{THINGER_BUCKET}/data"

# ⚠️ Replace this with a valid Thinger Access Token (bucket read)
THINGER_TOKEN = "YOUR_NEW_ACCESS_TOKEN"

# ---------------- MAIN ----------------
def fetch_sensor_data():
    headers = {"Authorization": f"Bearer {THINGER_TOKEN}"}
    response = requests.get(THINGER_URL, headers=headers)

    print("Status:", response.status_code)
    if response.status_code != 200:
        print("Error:", response.text)
        return None
    
    data = response.json()
    print("Raw Response:", data)
    
    if data:
        print("Latest Values:", data[0]["values"])
        return data[0]["values"]
    else:
        print("No data found in bucket!")
        return None

if __name__ == "__main__":
    fetch_sensor_data()
