#to run-->
#  python "preprocess_and_compute_aqi.py"

# preprocess_and_compute_aqi.py
import pandas as pd
import numpy as np

# Load raw dataset
df = pd.read_csv("nungambakkam_raw.csv")

print("✅ Raw Data Loaded:", df.shape)

# 1. Handle missing values
df = df.dropna()
print("✅ After dropping NaN:", df.shape)

# 2. Rename columns for consistency (adjust based on your file)
df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
print("✅ Columns:", df.columns.tolist())

# 3. Example: Assume pollutants available (adjust names to your dataset)
# Let's say your file has 'pm2.5', 'pm10', 'co', 'so2', 'no2', 'o3'
pollutants = ["pm2_5", "pm10", "no2", "so2", "o3", "co"]


for col in pollutants:
    if col not in df.columns:
        print(f"⚠️ Warning: {col} not found in dataset")

# 4. Compute AQI (simple approach = max of pollutant values)
df["AQI"] = df[pollutants].max(axis=1)

# 5. Add AQI Category
def categorize_aqi(aqi):
    if aqi <= 50:
        return "Good"
    elif aqi <= 100:
        return "Moderate"
    elif aqi <= 150:
        return "Unhealthy for Sensitive Groups"
    elif aqi <= 200:
        return "Unhealthy"
    elif aqi <= 300:
        return "Very Unhealthy"
    else:
        return "Hazardous"

df["AQI_Category"] = df["AQI"].apply(categorize_aqi)

# 6. Save preprocessed dataset
df.to_csv("mpaqi_data_collections.csv", index=False)
print("✅ Preprocessed & AQI computed → saved to 'mpaqi_data_collections.csv'")

# Quick check
print(df.head(5))
