##to run
## click teh run button
## CODE FOR THE AIR POLLUTION DATA USING IOT SESNORS + OPEANWEATHER API

import requests
import csv
import time
import os
from datetime import datetime

# CONFIGURATION AND CREDENTIALS
THINGER_USERNAME = "jknehavardhini"
THINGER_DEVICE = "pollucast_device"
THINGER_RESOURCE = "environment_data"
THINGER_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJwb2xsdWNhc3RfZGV2aWNlIiwiaWF0IjoxNzUzMTI1NzU2LCJqdGkiOiI2ODdlOTM3Y2E2MWQ5ODUyZmEwZmYwZTIiLCJzdnIiOiJhcC1zb3V0aGVhc3QuYXdzLnRoaW5nZXIuaW8iLCJ1c3IiOiJqa25laGF2YXJkaGluaSJ9.zgu5VPiFgAqst2PP--Upnx-oyHIDUAXG1pF28JxuquI"
OPENWEATHER_API_KEY = "09f32567882a99651d51fd9064202419"
CITY_NAME = "Chennai"
CSV_FILE = "mpaqi_data_collections1.csv"

# A FUNCTION TO GET THE SENSOR DATA FROM THE THINGER.IO(CLOUD)
def get_sensor_data():
    url = f"https://backend.thinger.io/v3/users/{THINGER_USERNAME}/devices/{THINGER_DEVICE}/resources/{THINGER_RESOURCE}"
    headers = {
        "Authorization": f"Bearer {THINGER_TOKEN}"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        print("❌ Error getting Thinger data:", response.text)
        return None

# === Function to get weather data from OpenWeatherMap ===
def get_weather_data():
    url = f"https://api.openweathermap.org/data/2.5/weather?q={CITY_NAME}&appid={OPENWEATHER_API_KEY}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return {
            "pressure": data["main"]["pressure"],
            "wind_speed": data["wind"]["speed"],
            "weather": data["weather"][0]["main"]
        }
    else:
        print("❌ Error getting weather data:", response.text)
        return None

# === Main Logging Loop ===
def log_data():
    print("🟢 Logging started... Press Ctrl+C to stop.")

    # Determine if CSV file already exists and if it has data
    file_exists = os.path.exists(CSV_FILE)
    write_header = not file_exists or os.stat(CSV_FILE).st_size == 0

    # Calculate the starting serial number if file exists
    serial_no = 1
    if file_exists and not write_header:
        with open(CSV_FILE, mode='r') as f:
            reader = csv.reader(f)
            rows = list(reader)
            for row in reversed(rows):
                if row and row[0].isdigit():
                    serial_no = int(row[0]) + 1
                    break


    with open(CSV_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)

        if write_header:
            writer.writerow(["S.No", "Timestamp", "Temp", "Humidity", "Gas", "Pressure", "Wind", "Weather"])

        while True:
            sensor = get_sensor_data()
            weather = get_weather_data()

            if sensor and weather:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                temperature = sensor.get("temperature", "null")
                humidity = sensor.get("humidity", "null")
                gas = sensor.get("gas", "null")

                row = [
                    serial_no,
                    timestamp,
                    temperature,
                    humidity,
                    gas,
                    weather["pressure"],
                    weather["wind_speed"],
                    weather["weather"]
                ]
                writer.writerow(row)
                print("✅ Data saved:", row)

                serial_no += 1

            time.sleep(10)

# === Run Logger ===
log_data()
