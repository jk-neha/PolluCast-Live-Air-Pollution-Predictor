# train_aqi_xgboost.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb
import joblib

# Load dataset
data = pd.read_csv("mpaqi_data_collections.csv")

print(f"\n✅ Data Loaded for Training: {data.shape}")
print(f"Columns: {list(data.columns)}\n")

# Features and Target
X = data[['pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']]
y = data['AQI']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"🔹 Training set: {X_train.shape}  | Test set: {X_test.shape}\n")

# Initialize XGBoost model
xgb_model = xgb.XGBRegressor(
    n_estimators=300,
    learning_rate=0.1,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42
)

# Train
xgb_model.fit(X_train, y_train)

# Predictions
y_pred = xgb_model.predict(X_test)

# Evaluation
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)
accuracy = 100 * (1 - mae / y_test.mean())

print("\n📊 XGBoost Performance:")
print("MAE :", mae)
print("RMSE:", rmse)
print("R²  :", r2)
print(f"Accuracy: {accuracy:.2f}%")

# Save model
joblib.dump(xgb_model, "aqi_xgb_model.pkl")
print("\n✅ XGBoost model saved as 'aqi_xgb_model.pkl'")
