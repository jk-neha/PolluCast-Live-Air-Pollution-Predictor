# to run
#  python visual.py       

# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# -----------------------------
# 1. Load Dataset
# -----------------------------
data = pd.read_csv("mpaqi_data_collections.csv")  # Replace with your CSV path

# -----------------------------
# 2. Feature Selection
# -----------------------------
# Use sensor readings as features
features = ['pm2_5','pm10','co','no','no2','o3','so2','nh3']
target = 'AQI'

X = data[features]
y = data[target]

# -----------------------------
# 3. Train/Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# -----------------------------
# 4. Initialize Models
# -----------------------------
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
svr_model = SVR(kernel='rbf')
xgb_model = XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42)

# -----------------------------
# 5. Train Models
# -----------------------------
rf_model.fit(X_train, y_train)
svr_model.fit(X_train, y_train)
xgb_model.fit(X_train, y_train)

# -----------------------------
# 6. Predictions
# -----------------------------
y_pred_rf = rf_model.predict(X_test)
y_pred_svr = svr_model.predict(X_test)
y_pred_xgb = xgb_model.predict(X_test)

# -----------------------------
# 7. Evaluation Function
# -----------------------------
def evaluate_model(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2

rf_metrics = evaluate_model(y_test, y_pred_rf)
svr_metrics = evaluate_model(y_test, y_pred_svr)
xgb_metrics = evaluate_model(y_test, y_pred_xgb)

print("Random Forest Metrics:", rf_metrics)
print("SVR Metrics:", svr_metrics)
print("XGBoost Metrics:", xgb_metrics)

# -----------------------------
# 8. Visualizations
# -----------------------------
# 8.1 Actual vs Predicted AQI
plt.figure(figsize=(12,6))
plt.plot(y_test.values, label='Actual', color='blue')
plt.plot(y_pred_rf, label='RF Predicted', color='green')
plt.plot(y_pred_svr, label='SVR Predicted', color='orange')
plt.plot(y_pred_xgb, label='XGB Predicted', color='red')
plt.title("Actual vs Predicted AQI")
plt.xlabel("Samples")
plt.ylabel("AQI")
plt.legend()
plt.savefig("actual_vs_predicted_aqi.png")
plt.show()

# 8.2 Error Distribution
plt.figure(figsize=(12,6))
sns.histplot(y_test - y_pred_rf, color='green', label='RF Error', kde=True, bins=30)
sns.histplot(y_test - y_pred_svr, color='orange', label='SVR Error', kde=True, bins=30)
sns.histplot(y_test - y_pred_xgb, color='red', label='XGB Error', kde=True, bins=30)
plt.title("Prediction Error Distribution")
plt.xlabel("Error (Actual - Predicted)")
plt.ylabel("Frequency")
plt.legend()
plt.savefig("error_distribution.png")
plt.show()

# 8.3 Feature Importance for RF and XGB
# Random Forest
rf_importance = pd.Series(rf_model.feature_importances_, index=features).sort_values(ascending=False)
plt.figure(figsize=(10,5))
rf_importance.plot(kind='bar', color='green')
plt.title("Random Forest Feature Importance")
plt.ylabel("Importance")
plt.savefig("rf_feature_importance.png")
plt.show()

# XGBoost
xgb_importance = pd.Series(xgb_model.feature_importances_, index=features).sort_values(ascending=False)
plt.figure(figsize=(10,5))
xgb_importance.plot(kind='bar', color='red')
plt.title("XGBoost Feature Importance")
plt.ylabel("Importance")
plt.savefig("xgb_feature_importance.png")
plt.show()

# 8.4 Model Comparison (MAE, RMSE, R2)
metrics_df = pd.DataFrame({
    'Model': ['Random Forest', 'SVR', 'XGBoost'],
    'MAE': [rf_metrics[0], svr_metrics[0], xgb_metrics[0]],
    'RMSE': [rf_metrics[1], svr_metrics[1], xgb_metrics[1]],
    'R2': [rf_metrics[2], svr_metrics[2], xgb_metrics[2]],
    
})

metrics_df.set_index('Model', inplace=True)
metrics_df.plot(kind='bar', figsize=(12,6))
plt.title("Model Performance Comparison")
plt.ylabel("Metric Value")
plt.xticks(rotation=0)
plt.savefig("model_comparison.png")
plt.show()

# -----------------------------
# 8.3 Feature Importance Combined
# -----------------------------
import matplotlib.ticker as mtick

# Random Forest Feature Importance
rf_importance = pd.Series(rf_model.feature_importances_, index=features)
# XGBoost Feature Importance
xgb_importance = pd.Series(xgb_model.feature_importances_, index=features)

# Combine into DataFrame
importance_df = pd.DataFrame({
    'Feature': features,
    'Random Forest': rf_importance.values,
    'XGBoost': xgb_importance.values
})

# Plot grouped bar chart
importance_df.set_index('Feature').plot(kind='bar', figsize=(12,6))
plt.title("Feature Importance Comparison: RF vs XGBoost")
plt.ylabel("Importance")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.savefig("combined_feature_importance.png")
plt.show()

# -----------------------------
# 8.5 Model Performance Table
# -----------------------------
metrics_df = pd.DataFrame({
    'Model': ['Random Forest', 'SVR', 'XGBoost'],
    'MAE': [rf_metrics[0], svr_metrics[0], xgb_metrics[0]],
    'RMSE': [rf_metrics[1], svr_metrics[1], xgb_metrics[1]],
    'R2 (Accuracy)': [rf_metrics[2], svr_metrics[2], xgb_metrics[2]]
})

print("Model Performance Metrics:")
print(metrics_df)

# Optional: Plot metrics comparison
metrics_df.set_index('Model')[['MAE','RMSE','R2 (Accuracy)']].plot(kind='bar', figsize=(12,6))
plt.title("Model Performance Comparison")
plt.ylabel("Metric Value")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("model_performance_comparison.png")
plt.show()

# Plot metrics comparison with zoomed y-axis
metrics_df.set_index('Model')[['MAE','RMSE','R2 (Accuracy)']].plot(kind='bar', figsize=(12,6))
plt.title("Model Performance Comparison (Zoomed Y-axis)")
plt.ylabel("Metric Value")
plt.xticks(rotation=0)
plt.ylim(0, metrics_df[['MAE','RMSE']].max().max() * 1.1)  # Zoom for MAE/RMSE, R2 will stay <1
plt.tight_layout()
plt.savefig("model_performance_comparison_zoomed.png")
plt.show()

# Model Accuracy Comparison with custom Y-axis and labels
plt.figure(figsize=(8,5))
accuracy_df = metrics_df.set_index('Model')['R2 (Accuracy)']  # Keep as 0-1
bars = accuracy_df.plot(kind='bar', color=['green', 'orange', 'red'])
plt.title("Model Accuracy (R²) Comparison")
plt.ylabel("Accuracy")
plt.ylim(0.95, 1.0)  # Y-axis from 0.95 to 1.0
plt.yticks([0.95, 0.96, 0.97, 0.98, 0.99, 1.0])  # Custom ticks
plt.xticks(rotation=0)

# Add percentage labels on top of each bar
for i, val in enumerate(accuracy_df):
    plt.text(i, val + 0.001, f"{val*100:.2f}%", ha='center', va='bottom', fontsize=10)

plt.tight_layout()
plt.savefig("model_accuracy_comparison_percentage.png")
plt.show()
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset and predictions
data = pd.read_csv("mpaqi_data_collections.csv")  # Replace with your CSV
y_test = data['AQI'][:10]  # Use first 10 rows for clarity
y_pred_rf = rf_model.predict(data[features])[:10]
y_pred_svr = svr_model.predict(data[features])[:10]
y_pred_xgb = xgb_model.predict(data[features])[:10]

# Convert timestamp for x-axis
timestamps = pd.to_datetime(data['timestamp_utc'][:500])

# Plot
plt.figure(figsize=(10,5))
plt.plot(timestamps, y_test, marker='o', label='Actual AQI', color='blue')
plt.plot(timestamps, y_pred_rf, marker='x', label='RF Predicted', color='green')
plt.plot(timestamps, y_pred_svr, marker='s', label='SVR Predicted', color='orange')
plt.plot(timestamps, y_pred_xgb, marker='^', label='XGB Predicted', color='red')
plt.title("Predicted vs Actual AQI Comparison (First 10 Samples)")
plt.xlabel("Timestamp")
plt.ylabel("AQI")
plt.xticks(rotation=45)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig("predicted_vs_actual_aqi_comparison.png", dpi=300)
plt.show()
