# to run -->
# python train_aqi_svr.py

import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 1. Load dataset
data = pd.read_csv("mpaqi_data_collections.csv")

print(f"\n✅ Data Loaded for Training: {data.shape}")
print("Columns:", list(data.columns))

# 2. Features & Target
features = ['pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']
X = data[features]
y = data['AQI']

# 3. Standardize features (important for SVR)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

print(f"\n🔹 Training set: {X_train.shape} | Test set: {X_test.shape}")

# 5. Initialize & Train SVR
svr_model = SVR(kernel='rbf', C=100, gamma=0.1, epsilon=0.1)  
svr_model.fit(X_train, y_train)

# 6. Predictions
y_pred = svr_model.predict(X_test)

# 7. Evaluate
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

accuracy = (1 - (np.mean(np.abs(y_test - y_pred)) / np.mean(y_test))) * 100

print("\n📊 SVR Model Performance:")
print("MAE :", mae)
print("RMSE:", rmse)
print("R²  :", r2)
print(f"Accuracy: {accuracy:.2f}%")

# 8. Save Model & Scaler
joblib.dump(svr_model, "aqi_svr_model.pkl")
joblib.dump(scaler, "svr_scaler.pkl")
print("\n✅ SVR model saved as 'aqi_svr_model.pkl' and scaler as 'svr_scaler.pkl'")
