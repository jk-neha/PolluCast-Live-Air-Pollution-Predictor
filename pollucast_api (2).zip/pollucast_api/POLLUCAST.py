import requests
import json
from datetime import datetime

# 🔑 Your Thinger.io credentials
THINGER_USERNAME = "jknehavardhini"
THINGER_DEVICE = "pollucast_device"
THINGER_BUCKET = "pollucast_data"
THINGER_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJwb2xsdWNhc3RfZGV2aWNlIiwiaWF0IjoxNzUzMTI1NzU2LCJqdGkiOiI2ODdlOTM3Y2E2MWQ5ODUyZmEwZmYwZTIiLCJzdnIiOiJhcC1zb3V0aGVhc3QuYXdzLnRoaW5nZXIuaW8iLCJ1c3IiOiJqa25laGF2YXJkaGluaSJ9.zgu5VPiFgAqst2PP--Upnx-oyHIDUAXG1pF28JxuquI"
# ------------------------------------------------------
# Fetch data from Thinger.io bucket
# ------------------------------------------------------
def fetch_sensor_data():
    url = f"https://api.thinger.io/v3/users/{THINGER_USERNAME}/buckets/{THINGER_BUCKET}/data"
    headers = {"Authorization": f"Bearer {THINGER_TOKEN}"}

    try:
        response = requests.get(url, headers=headers)

        print("🔎 Raw Response Status:", response.status_code)

        if response.status_code != 200:
            print("❌ Error fetching bucket data:", response.text)
            return None

        data = response.json()

        if not data or "val" not in data:
            print("⚠️ No 'val' found in bucket response:", data)
            return None

        # ✅ Extract sensor values
        return {
            "temp": data["val"].get("temp"),
            "humi": data["val"].get("humi"),
            "gas": data["val"].get("gas"),
        }

    except Exception as e:
        print("❌ Exception in fetch_sensor_data:", str(e))
        return None


# ------------------------------------------------------
# Main Loop (Demo)
# ------------------------------------------------------
def main():
    print("📡 Collecting live data...")

    sensor = fetch_sensor_data()
    if not sensor:
        print("⚠️ No sensor data available, skipping...")
        return

    row = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "temp": sensor["temp"],
        "humi": sensor["humi"],
        "gas": sensor["gas"],
    }

    print("✅ Data Row:", row)


if __name__ == "__main__":
    main()
