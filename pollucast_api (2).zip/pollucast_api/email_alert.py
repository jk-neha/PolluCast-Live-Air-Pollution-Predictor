import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ====== Configuration ======
SENDER_EMAIL = "airpollutionpredictor024@gmail.com"
APP_PASSWORD = "mhkk qidt flrn ybpv"   # 16-digit Google App Password
RECEIVER_EMAIL = "jknehavardhini2004@gmail.com"

def send_email_alert(aqi_value, category):
    subject = f"⚠️ Air Quality Alert: {category}"
    body = f"""
    Hello,

    The predicted AQI is {aqi_value:.2f}.
    Current air quality falls under: {category}.

    Please take precautions if going outside.

    Regards,
    PolluCast System 🌍
    """

    # Setup email
    msg = MIMEMultipart()
    msg["From"] = SENDER_EMAIL
    msg["To"] = RECEIVER_EMAIL
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        # Connect to Gmail SMTP
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(SENDER_EMAIL, APP_PASSWORD)
        server.sendmail(SENDER_EMAIL, RECEIVER_EMAIL, msg.as_string())
        server.quit()
        print(f"✅ Alert email sent to {RECEIVER_EMAIL}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# ====== Example Usage ======
if __name__ == "__main__":
    predicted_aqi = 246  # Replace with model prediction
    if predicted_aqi > 200:
        send_email_alert(predicted_aqi, "Unhealthy")
