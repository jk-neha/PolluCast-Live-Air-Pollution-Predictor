

import pandas as pd

# --------------------------
# File paths
# --------------------------
iot_api_file = r"C:\Users\Neha\Neha's-DESKTOP\pollucast_api\mpaqi_data_collections1.csv"  # Your IoT dataset
api_file = r"C:\Users\Neha\Neha's-DESKTOP\pollucast_api\nungambakkam_raw.csv"              # Your API-only dataset
merged_file = r"C:\Users\Neha\Neha's-DESKTOP\pollucast_api\merged_live_dataset.csv"       # Output merged CSV

# --------------------------
# Load datasets
# --------------------------
iot_df = pd.read_csv(iot_api_file)
api_df = pd.read_csv(api_file)

print("IoT dataset columns:", iot_df.columns)
print("API dataset columns:", api_df.columns)

# --------------------------
# Rename IoT timestamp column to match API dataset
# --------------------------
iot_df.rename(columns={'Timestamp': 'timestamp_utc'}, inplace=True)

# --------------------------
# Merge datasets on timestamp_utc
# --------------------------
merged_df = pd.merge(iot_df, api_df, on='timestamp_utc', how='outer')

# --------------------------
# Optional: reorder columns
# --------------------------
merged_df = merged_df[['S.No', 'timestamp_utc', 'Temp', 'Humidity', 'Gas', 'Pressure', 'Wind', 'Weather',
                       'timestamp_unix', 'timestamp_ist', 'aqi', 'pm2_5', 'pm10', 'co', 'no', 'no2', 'o3', 'so2', 'nh3']]

# --------------------------
# Save merged dataset
# --------------------------
merged_df.to_csv(merged_file, index=False)
print(f"Merged dataset saved at: {merged_file}")

# --------------------------
# Optional: Live data append example
# --------------------------
# If you collect new IoT/API data in the future, just load it into iot_new_df/api_new_df,
# repeat renaming, then append:
# merged_df = pd.concat([merged_df, new_merged_df], ignore_index=True)
# merged_df.to_csv(merged_file, index=False)



