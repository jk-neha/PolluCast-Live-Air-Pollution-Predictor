##to run-->
#python "compare_rf_xgboost.py"

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import xgboost as xgb

# Load dataset
df = pd.read_csv("mpaqi_data_collections.csv")

print("\n📌 Columns in dataset:", df.columns.tolist())

# Select target column "aqi" (from your dataset)
target_col = "aqi"

# Drop non-numeric columns (timestamps, categories)
drop_cols = ["timestamp_unix", "timestamp_utc", "timestamp_ist", "AQI_Category"]
X = df.drop(columns=drop_cols + [target_col], errors="ignore")
y = df[target_col]

print("\n✅ Features used for training:", X.columns.tolist())

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --- Random Forest ---
rf = RandomForestRegressor(random_state=42)
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)

# --- XGBoost ---
xg = xgb.XGBRegressor(random_state=42, n_estimators=200, learning_rate=0.1)
xg.fit(X_train, y_train)
xg_preds = xg.predict(X_test)

# --- Evaluation ---
def evaluate_model(name, y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    print(f"{name} -> MSE: {mse:.2f}, R²: {r2:.4f}")

print("\n📊 Model Performance Comparison:")
evaluate_model("Random Forest", y_test, rf_preds)
evaluate_model("XGBoost", y_test, xg_preds)



