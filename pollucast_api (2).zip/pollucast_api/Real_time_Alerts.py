## to run -> python Alerts_2_all.py

import pandas as pd
from datetime import datetime
from twilio.rest import Client
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import time

# ========================
# Twilio config
# ========================
TWILIO_ACCOUNT_SID = 'AC9ef71738abaf53908d9e599148b430bd'
TWILIO_AUTH_TOKEN = '1ec0a96f8df00ca23c6083b607e68923'
TWILIO_SMS_NUMBER = '+17163404256'
TWILIO_WHATSAPP_NUMBER = 'whatsapp:+14155238886'
twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# ========================
# Email config
# ========================
SENDER_EMAIL = 'airpollutionpredictor024@gmail.com'
APP_PASSWORD = 'mhkk qidt flrn ybpv'

# ========================
# Paths
# ========================
CSV_PATH = 'mpaqi_data_collections.csv'
LOG_PATH = 'aqi_alert_log.csv'

# ========================
# Recipients
# ========================
EMAIL_RECIPIENTS = [
    "fjknehvardhini@gmail.com",
    "jknehavardhini1234@gmail.com"
]

SMS_RECIPIENTS = [
    "+918122978440",
    "+919176364447"
]

WHATSAPP_RECIPIENTS = [
    "whatsapp:+918122978440",
    "whatsapp:+919176364447"
]

# ========================
# AQI Category
# ========================
def get_aqi_category(aqi):
    if aqi <= 50:
        return "Good (Safe)"
    elif aqi <= 100:
        return "Moderate (Safe)"
    elif aqi <= 150:
        return "Unhealthy for Sensitive Groups (Unsafe)"
    elif aqi <= 200:
        return "Unhealthy (Unsafe)"
    elif aqi <= 300:
        return "Very Unhealthy (Unsafe)"
    else:
        return "Hazardous (Unsafe)"

# ========================
# Alert sending function
# ========================
def send_alerts(latest_aqi, aqi_category, alert_message):
    alert_status = []

    # --- SMS ---
    for number in SMS_RECIPIENTS:
        try:
            sms = twilio_client.messages.create(
                body=alert_message,
                from_=TWILIO_SMS_NUMBER,
                to=number
            )
            print(f"✅ SMS sent to {number}: {sms.sid}")
            alert_status.append(f"SMS:{number}=Sent")
        except Exception as e:
            print(f"❌ Failed to send SMS to {number}: {e}")
            alert_status.append(f"SMS:{number}=Failed")

    # --- WhatsApp ---
    for number in WHATSAPP_RECIPIENTS:
        try:
            wa = twilio_client.messages.create(
                body=alert_message,
                from_=TWILIO_WHATSAPP_NUMBER,
                to=number
            )
            print(f"✅ WhatsApp sent to {number}: {wa.sid}")
            alert_status.append(f"WA:{number}=Sent")
        except Exception as e:
            print(f"❌ Failed to send WhatsApp to {number}: {e}")
            alert_status.append(f"WA:{number}=Failed")

    # --- Email ---
    for email in EMAIL_RECIPIENTS:
        try:
            msg = MIMEMultipart()
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            msg['Subject'] = f"⚠️ PolluCast AQI Alert: {aqi_category}"
            msg.attach(MIMEText(alert_message, 'plain'))

            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(SENDER_EMAIL, APP_PASSWORD)
            server.send_message(msg)
            server.quit()

            print(f"✅ Email sent to {email}")
            alert_status.append(f"Email:{email}=Sent")
        except Exception as e:
            print(f"❌ Failed to send Email to {email}: {e}")
            alert_status.append(f"Email:{email}=Failed")

    # --- Log alerts ---
    log_data = pd.DataFrame([{
        'Timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'AQI': latest_aqi,
        'AQI_Category': aqi_category,
        'Alert_Status': " | ".join(alert_status)
    }])

    if os.path.exists(LOG_PATH):
        log_data.to_csv(LOG_PATH, mode='a', header=False, index=False)
    else:
        log_data.to_csv(LOG_PATH, mode='w', header=True, index=False)

    print("✅ Alert logged in", LOG_PATH)

# ========================
# Real-time monitoring
# ========================
last_alert_time = None

print("🟢 PolluCast Real-Time Alert System Started...")

while True:
    try:
        df = pd.read_csv(CSV_PATH)
        if df.empty:
            time.sleep(5)
            continue

        latest_row = df.iloc[-1]
        latest_aqi = latest_row['AQI']
        latest_timestamp = latest_row['Timestamp']  # make sure CSV has Timestamp column

        if last_alert_time is None or latest_timestamp > last_alert_time:
            aqi_category = get_aqi_category(latest_aqi)
            alert_message = f"⚠️ PolluCast Alert!\nPredicted AQI: {latest_aqi}\nCategory: {aqi_category}\nStay safe 🌿"
            print(f"[{datetime.now()}] New AQI detected, sending alerts...")
            send_alerts(latest_aqi, aqi_category, alert_message)
            last_alert_time = latest_timestamp

    except Exception as e:
        print(f"⚠️ Error: {e}")

    time.sleep(10)  # check every 10 seconds
