import requests
import time
from datetime import datetime, timedelta, timezone
import pandas as pd
import os

# === EDIT THIS ===
API_KEY = "09f32567882a99651d51fd9064202419"  # Replace with your key
LOCATION_NAME = "Nungambakkam,Chennai,IN"
START_IST_STR = "2025-07-23 23:25:58"
END_IST_STR   = "2025-09-21 23:59:59"
DATA_FOLDER = r"C:\Users\Neha\Neha's-DESKTOP\pollucast_api"
# =================

def ist_to_utc_epoch(ist_str):
    ist = timezone(timedelta(hours=5, minutes=30))
    dt_ist = datetime.strptime(ist_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=ist)
    dt_utc = dt_ist.astimezone(timezone.utc)
    return int(dt_utc.timestamp()), dt_utc

def geocode_location(location, api_key):
    url = "http://api.openweathermap.org/geo/1.0/direct"
    params = {"q": location, "limit": 1, "appid": api_key}
    r = requests.get(url, params=params)
    r.raise_for_status()
    arr = r.json()
    if not arr:
        raise ValueError(f"Geocoding returned no results for location: {location}")
    return float(arr[0]["lat"]), float(arr[0]["lon"])

def fetch_air_pollution_history(lat, lon, start_ts, end_ts, api_key, chunk_days=7):
    url = "http://api.openweathermap.org/data/2.5/air_pollution/history"
    rows = []
    chunk_seconds = chunk_days * 24 * 3600
    cur_start = start_ts
    while cur_start <= end_ts:
        cur_end = min(cur_start + chunk_seconds - 1, end_ts)
        params = {"lat": lat, "lon": lon, "start": cur_start, "end": cur_end, "appid": api_key}
        print(f"Fetching: {datetime.utcfromtimestamp(cur_start)} -> {datetime.utcfromtimestamp(cur_end)}")
        resp = requests.get(url, params=params)
        data = resp.json()
        for item in data.get("list", []):
            ts = item.get("dt")
            main = item.get("main", {})
            comps = item.get("components", {})
            row = {
                "timestamp_utc": pd.to_datetime(ts, unit="s"),
                "timestamp_unix": ts,
                "aqi": main.get("aqi"),
                "co": comps.get("co"),
                "no": comps.get("no"),
                "no2": comps.get("no2"),
                "o3": comps.get("o3"),
                "so2": comps.get("so2"),
                "pm2_5": comps.get("pm2_5"),
                "pm10": comps.get("pm10"),
                "nh3": comps.get("nh3"),
            }
            rows.append(row)
        time.sleep(1)
        cur_start = cur_end + 1
    df = pd.DataFrame(rows)
    if not df.empty:
        ist_offset = timedelta(hours=5, minutes=30)
        df["timestamp_ist"] = df["timestamp_utc"] + ist_offset
        cols = ["timestamp_unix", "timestamp_utc", "timestamp_ist", "aqi", "pm2_5", "pm10",
                "co", "no", "no2", "o3", "so2", "nh3"]
        df = df[cols]
    return df

def main():
    lat, lon = geocode_location(LOCATION_NAME, API_KEY)
    start_ts, _ = ist_to_utc_epoch(START_IST_STR)
    end_ts, _ = ist_to_utc_epoch(END_IST_STR)
    df = fetch_air_pollution_history(lat, lon, start_ts, end_ts, API_KEY)
    if df.empty:
        print("No data fetched.")
        return
    os.makedirs(DATA_FOLDER, exist_ok=True)
    out_file = os.path.join(DATA_FOLDER, "nungambakkam_raw.csv")
    df.to_csv(out_file, index=False)
    print(f"✅ Raw data saved as: {out_file}")
    print(df.head())

if __name__ == "__main__":
    main()
