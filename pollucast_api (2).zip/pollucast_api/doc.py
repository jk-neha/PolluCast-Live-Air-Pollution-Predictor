import matplotlib.pyplot as plt
import pandas as pd

# Read CSV
df = pd.read_csv("mpaqi_data_collections.csv")

# Use only the first 10 rows for plotting
df_subset = df.head(500)  # or df.iloc[:10]

# Convert timestamp to datetime
timestamps = pd.to_datetime(df_subset['timestamp_ist'])
aqi_values = df_subset['AQI']

# Plot

plt.figure(figsize=(12,6))

plt.plot(timestamps, aqi_values, marker='o', color='blue')
plt.title('End-to-End Live AQI Predictions (500 Entries)')
plt.xlabel('Timestamp')
plt.ylabel('Predicted AQI')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("figure_6_2_3_aqi_plot.png", dpi=300)
plt.show()
