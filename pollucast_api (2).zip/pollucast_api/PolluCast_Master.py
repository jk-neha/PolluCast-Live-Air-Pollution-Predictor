### to run-->
#  python PolluCast_Master.py

# ====================================================
# PolluCast Master Script: Collect → Predict → Alert
# ====================================================

import requests, os, pickle
import pandas as pd
from datetime import datetime
from twilio.rest import Client
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ---------------- CONFIG ----------------
THINGER_BUCKET = "pollucast_data"
THINGER_URL = f"https://api.thinger.io/v3/users/jknehavardhini/buckets/{THINGER_BUCKET}/data"
THINGER_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXYiOiJwb2xsdWNhc3RfZGV2aWNlIiwiaWF0IjoxNzUzMTI1NzU2LCJqdGkiOiI2ODdlOTM3Y2E2MWQ5ODUyZmEwZmYwZTIiLCJzdnIiOiJhcC1zb3V0aGVhc3QuYXdzLnRoaW5nZXIuaW8iLCJ1c3IiOiJqa25laGF2YXJkaGluaSJ9.zgu5VPiFgAqst2PP--Upnx-oyHIDUAXG1pF28JxuquI"

MODEL_PATH = "aqi_rf_model.pkl"
DATA_CSV = "mpaqi_data_collections.csv"
LOG_CSV = "aqi_alert_log.csv"

# Twilio
TWILIO_SID = "AC9ef71738abaf53908d9e599148b430bd"
TWILIO_TOKEN = "1ec0a96f8df00ca23c6083b607e68923"
TWILIO_SMS = "+17163404256"
TWILIO_WHATSAPP = "whatsapp:+14155238886"
twilio_client = Client(TWILIO_SID, TWILIO_TOKEN)

# Recipients
RECIPIENT_EMAILS = [
    "jknehavardhini2004@gmail.com",
    "friend1@gmail.com",
    "friend2@gmail.com"
]

RECIPIENT_SMS = [
    "+918122978440",  # your number
    "+919176364447",  # friend1
    "+918610685568"   # friend2
]

RECIPIENT_WHATSAPP = [
    "whatsapp:+918122978440",
    "whatsapp:+919176364447",
    "whatsapp:+918610685568"
]

# Gmail
SENDER_EMAIL = "airpollutionpredictor024@gmail.com"
APP_PASSWORD = "mhkk qidt flrn ybpv"

# ---------------- FUNCTIONS ----------------

def fetch_sensor_data():
    """Fetch latest data from Thinger bucket"""
    headers = {"Authorization": f"Bearer {THINGER_TOKEN}"}
    response = requests.get(THINGER_URL, headers=headers)
    if response.status_code != 200:
        print("❌ Error fetching sensor data:", response.text)
        return None
    data = response.json()
    return data[0]["values"] if data else None

def preprocess_data(raw):
    """Preprocess single reading into feature vector"""
    df = pd.DataFrame([raw])
    df["hour"] = datetime.now().hour
    df["day_of_week"] = datetime.now().weekday()
    df["is_weekend"] = 1 if df["day_of_week"].iloc[0] >= 5 else 0
    return df

def predict_aqi(features):
    """Load trained model and predict AQI"""
    model = pickle.load(open(MODEL_PATH, "rb"))
    prediction = model.predict(features)[0]
    return round(prediction, 2)

def get_aqi_category(aqi):
    if aqi <= 50: return "Good (Safe)"
    elif aqi <= 100: return "Moderate (Safe)"
    elif aqi <= 150: return "Unhealthy for Sensitive Groups"
    elif aqi <= 200: return "Unhealthy"
    elif aqi <= 300: return "Very Unhealthy"
    else: return "Hazardous"

def send_email(msg):
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(SENDER_EMAIL, APP_PASSWORD)

        for receiver in RECIPIENT_EMAILS:
            email = MIMEMultipart()
            email["From"], email["To"], email["Subject"] = SENDER_EMAIL, receiver, "⚠️ PolluCast AQI Alert"
            email.attach(MIMEText(msg, "plain"))
            server.send_message(email)
            print(f"✅ Email sent to {receiver}")

        server.quit()
    except Exception as e:
        print("❌ Email failed:", e)

def send_sms(msg):
    try:
        for number in RECIPIENT_SMS:
            sms = twilio_client.messages.create(body=msg, from_=TWILIO_SMS, to=number)
            print(f"✅ SMS sent to {number}: {sms.sid}")
    except Exception as e:
        print("❌ SMS failed:", e)

def send_whatsapp(msg):
    try:
        for number in RECIPIENT_WHATSAPP:
            wa = twilio_client.messages.create(body=msg, from_=TWILIO_WHATSAPP, to=number)
            print(f"✅ WhatsApp sent to {number}: {wa.sid}")
    except Exception as e:
        print("❌ WhatsApp failed:", e)

# ---------------- MAIN ----------------
def main():
    print("📡 Collecting live data...")
    raw = fetch_sensor_data()
    if not raw:
        return

    features = preprocess_data(raw)
    aqi = predict_aqi(features)
    category = get_aqi_category(aqi)

    msg = f"⚠️ PolluCast Alert!\nAQI: {aqi}\nCategory: {category}\nStay safe 🌿"
    print(msg)

    # Append to CSV
    features["AQI"] = aqi
    features["Timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if os.path.exists(DATA_CSV):
        features.to_csv(DATA_CSV, mode="a", header=False, index=False)
    else:
        features.to_csv(DATA_CSV, index=False)

    # Log
    log = pd.DataFrame([{"Timestamp": datetime.now(), "AQI": aqi, "Category": category}])
    if os.path.exists(LOG_CSV):
        log.to_csv(LOG_CSV, mode="a", header=False, index=False)
    else:
        log.to_csv(LOG_CSV, index=False)

    # Send alerts to all recipients
    send_email(msg)
    send_sms(msg)
    send_whatsapp(msg)

if __name__ == "__main__":
    main()
