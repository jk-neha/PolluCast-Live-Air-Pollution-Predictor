# to run--
# python whatsapp_alert.py

from twilio.rest import Client

account_sid = 'AC9ef71738abaf53908d9e599148b430bd'
auth_token = '1ec0a96f8df00ca23c6083b607e68923'
client = Client(account_sid, auth_token)

TWILIO_WHATSAPP = 'whatsapp:+14155238886'  # Sandbox number
MY_PHONE_WHATSAPP = 'whatsapp:+918122978440'  # Your WhatsApp number

message = client.messages.create(
    body='Hello from PolluCast! 🌿',
    from_=TWILIO_WHATSAPP,
    to=MY_PHONE_WHATSAPP
)

print("Message SID:", message.sid)
