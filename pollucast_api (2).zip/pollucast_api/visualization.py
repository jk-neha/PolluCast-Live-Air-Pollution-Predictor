
## AQI category-plots
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# --- Load CSV ---
df = pd.read_csv("mpaqi_data_collections.csv")
df.columns = df.columns.str.strip()

# --- Standardize AQI category names ---
df['AQI_Category'] = df['AQI_Category'].str.strip()

# --- Define base color map ---
color_map = {
    'Good (Safe)': 'red',
    'Moderate (Safe)': 'blue',
    'Unhealthy for Sensitive Groups (Unsafe)': 'black',
    'Unhealthy (Unsafe)': 'green',
    'Very Unhealthy (Unsafe)': 'purple',
    'Hazardous (Unsafe)': 'maroon'
}

# --- Map CSV categories to color_map keys using simple rules ---
def map_category(cat):
    cat = cat.lower()
    if 'good' in cat:
        return 'Good (Safe)'
    elif 'moderate' in cat:
        return 'Moderate (Safe)'
    
    elif 'sensitive' in cat or 'for sensitive' in cat:
        return 'Unhealthy for Sensitive Groups (Unsafe)'
    elif cat.startswith('unhealthy'):
        return 'Unhealthy (Unsafe)'
    elif 'very unhealthy' in cat:
        return 'Very Unhealthy (Unsafe)'
    elif 'hazardous' in cat:
        return 'Hazardous (Unsafe)'
    else:
        return 'Moderate (Safe)'  # default fallback

df['AQI_Category_Std'] = df['AQI_Category'].apply(map_category)

# --- Drop rows with missing AQI ---
df = df.dropna(subset=['AQI'])

# --- Compute average AQI per standardized category ---
category_stats = df.groupby('AQI_Category_Std')['AQI'].mean().sort_values()

# --- Horizontal bar plot ---
plt.figure(figsize=(10,6))
plt.barh(category_stats.index, category_stats.values,
         color=[color_map[c] for c in category_stats.index], edgecolor='black')

# Add AQI value labels
for i, (cat, val) in enumerate(category_stats.items()):
    plt.text(val + 1, i, f'{val:.1f}', va='center', fontsize=10)

plt.xlabel("Average Predicted AQI")
plt.ylabel("AQI Category")
plt.title("PolluCast AQI by Category")
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()

# --- Legend ---
legend_elements = [Patch(facecolor=c, label=l) for l, c in color_map.items()]
plt.legend(handles=legend_elements, title="AQI Category", bbox_to_anchor=(1.05, 1))

plt.show()
